package org.emulinker.kaillera.admin;

import org.picocontainer.Startable;

public interface AdminServer extends Startable
{

}
