package org.emulinker.kaillera.model.event;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.emulinker.kaillera.model.*;
import org.emulinker.kaillera.model.impl.KailleraServerImpl;

public class ChatEvent implements ServerEvent
{
	///
	protected static Log						log							= LogFactory.getLog(KailleraServerImpl.class);
	///
	private KailleraServer	server;
	private KailleraUser	user;
	private String			message;

	public ChatEvent(KailleraServer server, KailleraUser user, String message)
	{
		this.server = server;
		this.user = user;
		this.message = message;
		//log.info(this.user+this.message);
	}

	public String toString()
	{
		return "ChatEvent";
	}

	public KailleraServer getServer()
	{
		return server;
	}

	public KailleraUser getUser()
	{
		return user;
	}

	public String getMessage()
	{
		return message;
	}
}
