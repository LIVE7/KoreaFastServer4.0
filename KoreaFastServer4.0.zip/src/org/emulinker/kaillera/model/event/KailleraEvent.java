package org.emulinker.kaillera.model.event;

public interface KailleraEvent
{
	public String toString();
}
