package org.emulinker.kaillera.master.client;


public interface MasterListUpdateTask
{
	public void touchMaster();
}
