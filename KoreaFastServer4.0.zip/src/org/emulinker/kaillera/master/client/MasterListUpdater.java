package org.emulinker.kaillera.master.client;


public interface MasterListUpdater
{

}
