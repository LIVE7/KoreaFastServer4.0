/*2023.01.01 Ver3.6 Update*/

package org.emulinker.kaillera.master.client;

import java.util.Properties;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.emulinker.kaillera.controller.connectcontroller.ConnectController;
import org.emulinker.kaillera.master.PublicServerInformation;
import org.emulinker.kaillera.model.KailleraGame;
import org.emulinker.kaillera.model.KailleraServer;
import org.emulinker.release.ReleaseInfo;

public class EmuLinkerMasterUpdateTask implements MasterListUpdateTask {
  private static Log log = LogFactory.getLog(EmuLinkerMasterUpdateTask.class);
  
  private static final String url = "http://kaillerareborn.2manygames.fr/touch_list.php";
  
  private PublicServerInformation publicInfo;
  
  private ConnectController connectController;
  
  private KailleraServer kailleraServer;
  
  private ReleaseInfo releaseInfo;
  
  private HttpClient httpClient;
  
  public EmuLinkerMasterUpdateTask(PublicServerInformation publicInfo, ConnectController connectController, KailleraServer kailleraServer, ReleaseInfo releaseInfo) {
    this.publicInfo = publicInfo;
    this.connectController = connectController;
    this.kailleraServer = kailleraServer;
    this.publicInfo = publicInfo;
    this.releaseInfo = releaseInfo;
    this.httpClient = new HttpClient();
    this.httpClient.setConnectionTimeout(5000);
    this.httpClient.setTimeout(5000);
  }
  
  public void touchMaster() {
    StringBuilder waitingGames = new StringBuilder();
    for (KailleraGame game : this.kailleraServer.getGames()) {
      if (game.getStatus() != 0)
        continue; 
      waitingGames.append(game.getRomName());
      waitingGames.append("|");
      waitingGames.append(game.getOwner().getName());
      waitingGames.append("|");
      waitingGames.append(game.getOwner().getClientType());
      waitingGames.append("|");
      waitingGames.append(game.getNumPlayers());
      waitingGames.append("/");
      waitingGames.append(game.getMaxUsers());
      waitingGames.append("|");
    } 
    NameValuePair[] params = new NameValuePair[10];
    params[0] = new NameValuePair("serverName", this.publicInfo.getServerName());
    params[1] = new NameValuePair("ipAddress", this.publicInfo.getConnectAddress());
    params[2] = new NameValuePair("location", this.publicInfo.getLocation());
    params[3] = new NameValuePair("website", this.publicInfo.getWebsite());
    params[4] = new NameValuePair("port", Integer.toString(this.connectController.getBindPort()));
    /*2023.02.05 Ver3.9 Update*/
	params[5] = new NameValuePair("numUsers", Integer.toString(this.kailleraServer.getNumUsers()+32)); //������+32
    //params[5] = new NameValuePair("numUsers", Integer.toString(this.kailleraServer.getNumUsers()));
    params[6] = new NameValuePair("maxUsers", Integer.toString(this.kailleraServer.getMaxUsers()));
    params[7] = new NameValuePair("numGames", Integer.toString(this.kailleraServer.getNumGames()));
    params[8] = new NameValuePair("maxGames", Integer.toString(this.kailleraServer.getMaxGames()));
    params[9] = new NameValuePair("version", "KFS_" + this.releaseInfo.getVersionString());
    GetMethod getMethod = new GetMethod("http://kaillerareborn.2manygames.fr/touch_list.php");
    getMethod.setQueryString(params);
    getMethod.setRequestHeader("Waiting-games", waitingGames.toString());
    getMethod.setFollowRedirects(true);
    Properties props = new Properties();
    try {
      int statusCode = this.httpClient.executeMethod((HttpMethod)getMethod);
      if (statusCode != 200) {
        log.error("Failed to touch EmuLinker Master: " + getMethod.getStatusLine());
      } else {
        props.load(getMethod.getResponseBodyAsStream());
        /*2023.02.05 Ver3.9 Update*/
        //log.info("Touching EmuLinker Master done");
      } 
    } catch (Exception e) {
      log.error("Failed to touch EmuLinker Master: " + e.getMessage());
    } finally {
      if (getMethod != null)
        try {
          getMethod.releaseConnection();
        } catch (Exception exception) {} 
    } 
    String updateAvailable = props.getProperty("updateAvailable");
    if (updateAvailable != null && updateAvailable.equalsIgnoreCase("true")) {
      String latestVersion = props.getProperty("latest");
      String notes = props.getProperty("notes");
      StringBuilder sb = new StringBuilder();
      sb.append("A new version of the server is available: ");
      sb.append(latestVersion);
      if (notes != null) {
        sb.append(" (");
        sb.append(notes);
        sb.append(")");
      } 
      /*2023.01.07 Ver3.7 Update*/
      //log.warn(sb.toString());
    } 
  }
}