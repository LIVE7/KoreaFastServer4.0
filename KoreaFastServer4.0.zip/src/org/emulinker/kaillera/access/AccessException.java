package org.emulinker.kaillera.access;

public class AccessException extends Exception
{
	public AccessException(String message)
	{
		super(message);
	}
}
