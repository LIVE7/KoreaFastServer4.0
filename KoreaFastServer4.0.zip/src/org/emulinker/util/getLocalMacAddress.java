package org.emulinker.util;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
 
public class getLocalMacAddress {
 
    public static void main(String[] args)throws Exception {
         
        InetAddress ip = InetAddress.getLocalHost();
        // ��� : john-PC/192.168.206.1
//        System.out.println(ip);
         
        NetworkInterface mac = NetworkInterface.getByInetAddress(ip);
        // ��� : name:eth4 (VMware Virtual Ethernet Adapter for VMnet1)
//        System.out.println(mac);
 
         
//        if(ip != null) {
            byte[] mc = mac.getHardwareAddress();
             
            String macAddress = "";
             
            for (int i = 0; i < mc.length; i++) {
                macAddress += (String.format("%02x", mc[i]) + ":");
            }
             
            // ��� : 00:50:56:c0:00:01
            System.out.println(
                macAddress.substring(0, macAddress.length()-1)
            );
//        }
    }
    
    public String macAddr() {
    	InetAddress ip = null;
		try {
			ip = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // ��� : john-PC/192.168.206.1
//        System.out.println(ip);
         
        NetworkInterface mac = null;
		try {
			mac = NetworkInterface.getByInetAddress(ip);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // ��� : name:eth4 (VMware Virtual Ethernet Adapter for VMnet1)
//        System.out.println(mac);
 
         
//        if(ip != null) {
            byte[] mc = null;
			try {
				mc = mac.getHardwareAddress();
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             
            String macAddress = "";
             
            for (int i = 0; i < mc.length; i++) {
                macAddress += (String.format("%02x", mc[i]) + ":");
            }
             
            // ��� : 00:50:56:c0:00:01
//            System.out.println(
//                macAddress.substring(0, macAddress.length()-1)
//            );
			return macAddress.substring(0, macAddress.length()-1);
    }
    
}	