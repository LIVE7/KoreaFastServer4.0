package org.emulinker.util;
 
public class getLocalMacAddress2 {
 
    public static void main(String[] args)throws Exception {
     
    	getLocalMacAddress getMac = new getLocalMacAddress();
    	
    	String macAddress = getMac.macAddr();
    	
    	System.out.println(macAddress);
    	
    }
}	