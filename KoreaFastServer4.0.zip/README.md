# EmuLinkerSF
EmuLinkerSF is a modified version of EmuLinker Kaillera network server created by Moosehead with new features by Suprafast.
Original EmuLinker can be found here: https://github.com/monospacesoftware/emulinker
******************
This is unofficially updated version of EmulinkeSF, based on original latest source v72.3 (09-20-2009).
This version includes bug fixes and other improvements.
******************
